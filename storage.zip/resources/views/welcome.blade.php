@extends ('layout')

@section ('content')
 Welcome page

    @stop
@section ('content2')
    Welcome page

@stop

@section ('content3')
    Welcome page

@stop