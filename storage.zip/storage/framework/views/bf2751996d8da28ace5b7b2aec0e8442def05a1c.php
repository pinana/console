<!DOCTYPE html>
<html lang="en">
<html>
<body>

<?php $__env->startSection('sidebar'); ?>
    This is the master sidebar.
<?php echo $__env->yieldSection(); ?>

<div class="container">
    <h1> <?php echo $__env->yieldContent('content'); ?></h1>
    <h2> <?php echo $__env->yieldContent('content2'); ?></h2>
    <h3> <?php echo $__env->yieldContent('content2'); ?></h3>
</div>
</body>
</html>
